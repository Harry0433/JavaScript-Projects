// This will display an alert message when the page loads
window.alert("Hello! Welcome to my Basic JavaScript Project.");

// Create two variables with string values
var Sent1 = "This is the beginning of the string";
var Sent2 = " and this is the end of the string";

// Concatenate the variables and display the full sentence
document.write(Sent1 + Sent2);  // Output: This is the beginning of the string and this is the end of the string

// Write an expression (addition) to the console for testing
console.log(10 + 5); // Adds two numbers and logs the result (15) to the console
