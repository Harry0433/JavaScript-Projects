function combineText() {
    // Assign two variables
    var part1 = "Hello, ";
    var part2 = "welcome to Project 2 - Functions!";
    
    // Combine variables
    var fullSentence = part1 + part2;
    
    // Display the result inside the paragraph with id="output"
    document.getElementById("output").innerHTML = fullSentence;
}
